$(document).ready(function(){
  
  $("#add_emp").click(function() {
  	 var name =$("#emp_name").val();
  	 var email =$("#emp_email").val();
  	 var phone =$("#emp_phone").val();
  	 var status =$("#emp_status").val();


      $.ajax({
  	 	url: "clases/Process.php",
  	 	type: "POST",
  	 	data:{
           emp_name: name,
           emp_email: email,
           emp_phone: phone,
           emp_status: status,
           action: "insert"

  	 	},
  	 	success: function (response){
        $(".message").html(` 
             <div class="alert alert-success" role="alert">
              ${response}
            </div> `);
        $(".message").fadeOut(2000);
        $("#emp_name").val("");
        $("#emp_email").val("");
        $("#emp_phone").val("");
        $("#emp_status").val("");
          show();
  	 	}
  	 	
  	 });
  	 
  	 
  });

  //show
 show()
 function show(){
  $.ajax({
    url: "clases/Process.php",
    type: "POST",
    data: {
        action:"show"

    },
    success:function (response){
     $(".tbody").html(response);
    }
    
  });

 }

 //active button

 $(document).on("click","#activeBtn", function(){
    var id = $(this).val();


    $.ajax({
    url: "clases/Process.php",
    type: "POST",
    data: {
      id:id,
        action:"active"

    },
    success:function (response){
      show();
    }
    
  });

 });


 //inactive button

 $(document).on("click","#inactiveBtn", function(){
    var id = $(this).val();


    $.ajax({
    url: "clases/Process.php",
    type: "POST",
    data: {
      id:id,
        action:"inactive"

    },
    success:function (response){
      show();
    }
    
  });

 });

 //delete btn


 $(document).on("click","#deletBtn", function(){
    var id = $(this).val();


    $.ajax({
    url: "clases/Process.php",
    type: "POST",
    data: {
      id:id,
        action:"delete"

    },
    success:function (response){
      show();
    }
    
  });

 });



});